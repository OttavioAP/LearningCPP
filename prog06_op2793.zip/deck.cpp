#include <iostream>
#include <string>
#include "deck.h"
#include <cstdlib>
#include <ctime>



Deck::Deck() {
    for(myIndex = 0; myIndex <52;myIndex++){
        switch(myIndex) {//sets the suits
            case 0 ... 12  :
                myCards[myIndex].setSuit(Card::spades);
                break;
            case 13 ... 25  :
                myCards[myIndex].setSuit(Card::diamonds);
                break;
            case 26 ... 38  :
                myCards[myIndex].setSuit(Card::clubs);
                break;
            case 39 ... 51  :
                myCards[myIndex].setSuit(Card::hearts);
                break;
        }

        myCards[myIndex].setRank((myIndex%13)+1);//sets the ranks
    }

    myIndex = 51;


}
//allows any card to be viewed based on index
Card Deck::peek(int r) {
    return myCards[r];
}

int Deck::size() const {
return myIndex +1;
}

Card Deck::dealCard() {//returns the top card of the deck while decrementing the index (reduces size to not include the card to be returned);
if(myIndex <0){

    return myCards[0];
}
    myIndex--;
    return myCards[myIndex +1];
}

void Deck::shuffle() {
    srand (time(nullptr));

    if(this->size() < 2){

    return;
    }

    for(int i =0; i<5000; i++){
        int random = rand() % (myIndex +1) ;
        myCards[0].swap(myCards[random]);
    }

}

void Deck::showDeck() {

    for(int i = myIndex; i >=0; i--){

    }
}