

#include <iostream>
#include <string>
#include <vector>
#include "deck.h"
#include <cstdlib>
#include <ctime>

#include "player.h"
#include "card.h"
using namespace std;

void Player::moveCards(Card c, Player &currentPlayer) {
    int count =0;
    for (auto handElement: myHand) {
    if(c.sameRankAs(handElement)){
        currentPlayer.addCard(handElement);
        myHand.erase(myHand.begin()+count);
    }
    count++;
    }

//moves cards to p1s hand if they match

 }




//adds a card (given as a parameter) to the player objects hand
void Player::addCard(Card c) {
    this->myHand.push_back(c);
}

void Player::bookCards(Card c1, Card c2) {
    this->myBook.push_back(c1);
    this->myBook.push_back(c2);
}

bool Player::cardInHand(Card c) const {
    for (auto playerCard : myHand) {
        if(c == playerCard){
            return true;
        }
    }
    return false;
}

bool Player::checkHandForBook(Card &c1, Card &c2) {
    for (auto playerCard1 : myHand) {
        for(auto playerCard2 :myHand){
            if(playerCard1.sameRankAs(playerCard2) && playerCard1 != playerCard2){
                c1 = playerCard1;//
                c2 = playerCard2;
                return true;
            }
        }

    }
    return false;
}



Card Player::chooseCardFromHand() const {//randomly selects a card from the players hand and asks if the other player has that card
    srand (time(nullptr));
    int random = rand() % ( myHand.size() ) ;
    return myHand.at(random);
}

int Player::getBookSize() const {
    int count =0;
    for (auto bookItem : myBook) {
        bookItem =bookItem;
        count++;
    }
    return count;
}

int Player::getHandSize() const {
    int count =0;
    for (auto handItem : myHand) {
        handItem =handItem;
        count++;
    }
    return count;
}

bool Player::sameRankInHand(Card c) const {//checks if the other player has the same rank in hand
    for (auto handItem : myHand) {
        if(handItem.sameRankAs(c) && handItem != c)
    return true;
    }
    return false;
}

Card Player::removeCardFromHand(Card c) {
    int count =0;

   if(this->cardInHand(c) != true){

       return c;
   }

for(auto handItem: myHand){
    if(handItem == c){
        Card temp =myHand[count];
        myHand.erase(myHand.begin() +count);
        return(temp);
    }
    count++;
}

    return c;

}


string Player::showBooks() const {
  string retString =myBook[0].toString();

    if(myBook.size() < 1){
        return "empty\n";
    }
else

    for(unsigned int i =1; i < myBook.size();i++){

        retString = retString + ", " + myBook[i].toString();
    }

    retString = retString + "\n";



    return retString;
}





string Player::showHand() const {
    string retString =myHand[0].toString();

    if(myHand.size() <1){
        return "empty\n";
    }

    for(unsigned int i =1; i < myHand.size();i++){
       retString = retString +", " + myHand[i].toString();
    }

    retString = retString + "\n";



return retString;


}

