/*
 * implementation of card class
 */
#include <iostream>
#include <string>
#include "card.h"

//constructors

Card::Card() {
    myRank = 1;
    mySuit = spades;
}

Card::Card(int rank, Suit s) {
myRank = rank;
mySuit = s;
}

//accessors
int Card::getRank() const {
    return myRank;
}

Card::Suit Card::getSuit() const {
    return mySuit;
}

//mutators
void Card::setRank(int r) {
    myRank =r;
}

void Card::setSuit(Suit s) {
    mySuit = s;
}

//convertors
string Card::suitString(Suit s) const {
    switch(s) {
        case spades  :
            return "S";
        case clubs  :
            return "C";
        case hearts :
            return "H";
        case diamonds  :
            return "D";
        default : //Optional
            return "E";
    }
}

string Card::rankString(int r) const {
    string str = std::to_string(r);

    switch(r) {
        case -1  :
            return "error";
        case 1  :
            return "A";
        case 2:
            return str;
        case 3:
            return str;
        case 4:
            return str;
        case 5:
            return str;
        case 6:
            return str;
        case 7:
            return str;
        case 8:
            return str;
        case 9:
            return str;
        case 10:
            return str;
            return str;
        case 11 :
            return "J";
        case 12  :
            return "Q";
        case 13  :
            return "K";
        default : //Optional
        return "E";
    }

}

string Card::toString() const {
return rankString(this->myRank) + suitString(this->mySuit) ;

}

//comparison
bool Card::sameSuitAs(const Card &c) const {
return (this->mySuit == c.mySuit);
}

bool Card::sameRankAs(const Card &c) const {
    return (this->myRank == c.myRank);
}

//swap
void Card::swap(Card &rhs) {
    Card temp;
    temp.mySuit = this->mySuit;
    temp.myRank = this->myRank;

    this->myRank = rhs.myRank;
    this->mySuit = rhs.mySuit;

    rhs.myRank = temp.myRank;
    rhs.mySuit = temp.mySuit;
}

//operator overload

bool Card::operator==(const Card &rhs) const {
    return((this->mySuit == rhs.mySuit) &&(this->myRank == rhs.myRank));
}

bool Card::operator!=(const Card &rhs) const {
    return((this->mySuit != rhs.mySuit) || (this->myRank != rhs.myRank));
}

ostream& operator << (ostream& out, const Card& c)
{
    out << c.toString();
    return out;
}
