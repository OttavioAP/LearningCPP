ReadMe for GoFish, written by Ottavio Peruzzi (OP2793) on 11/12 2020

To run this program, unzip the zip file prog06_op2793.zip

Constituent files: 
ReadMe.txt
gofish_results.txt
makefile
player.cpp
player.h
card.h
card.cpp
deck.h
deck.cpp
go_fish.cpp

compile using the command <make>
run using <./goFish gofish_results.txt>

I determined who would go first with a virtual coin toss, a 50/50 chance either player goes first
games start with each player holding 7 cards and a book consists of only 2 cards
Players strategy is simple, they randomly guess based on the rank of one of the cards in their hand
I frequently record in the text log the hands and books of the players to show their aren't errors in how the game is played