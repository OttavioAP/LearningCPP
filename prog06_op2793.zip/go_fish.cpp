#include <iostream>    // Provides cout and cin
#include <cstdlib>     // Provides EXIT_SUCCESS
#include "card.h"
#include "player.h"
#include "deck.h"
#include <string.h>
#define HAND_SIZE 7
#define MAX_NAME 1000
#include <fstream>


using namespace std;

ofstream myFile;//global file printout variable

void dealHand(Deck &d, Player &p, int numCards){
    for(int i =0; i <numCards;i++){
        p.addCard(d.dealCard());
    }

}

void dealOneCard(Deck &d, Player &p){
        p.addCard(d.dealCard());
}

void goFish(Player &currentPlayer, Player &otherPlayer, Card c ){

    myFile<<otherPlayer.getName()<< " hands over every "<<c.rankString((c.getRank()))<< " in their hand"<<endl;
    otherPlayer.moveCards(c,currentPlayer);

    Card pairHolder1; Card pairHolder2;

    while(currentPlayer.checkHandForBook(pairHolder1,pairHolder2) ==true){
        currentPlayer.removeCardFromHand(pairHolder1);
        currentPlayer.removeCardFromHand(pairHolder2);
        currentPlayer.bookCards(pairHolder1,pairHolder2);    //add cards to book

        myFile<<currentPlayer.getName()<< " puts " <<pairHolder1<< " and "<<pairHolder2<< " into their book"<<endl;
    }


}

bool takeTurn(Deck &d, Player &currentPlayer, Player &otherPlayer){


if(currentPlayer.getHandSize() <1){//check if currentPlayer has a card
    if(d.size() <1){//checks if the game is ove
        myFile<<currentPlayer.getName()<< " is out of cards and the deck is empty."<<endl;
        return false;
    }
    myFile<<currentPlayer.getName();

    myFile<<"'s turn"<<endl;


    myFile<<currentPlayer.getName();
    myFile<<" has no cards so they draw one and end their turn"<<endl;
    dealOneCard(d,currentPlayer);
    return true;
}


    myFile<<currentPlayer.getName();
    myFile<<"'s turn"<<endl;
Card chosenCard = currentPlayer.chooseCardFromHand();


    myFile<<currentPlayer.getName()<< " asks if "<<otherPlayer.getName()<<" has any ";
    myFile<<chosenCard.rankString(chosenCard.getRank())<<"'s"<<endl;

bool playerGuess = otherPlayer.sameRankInHand(chosenCard);

if(playerGuess == true){

    myFile<<otherPlayer.getName()<< " does have at least one "<<    chosenCard.rankString(chosenCard.getRank())<<endl;
    goFish(currentPlayer,otherPlayer,chosenCard);





    myFile<<currentPlayer.getName()<<"'s hand is now ";


    myFile<<currentPlayer.showHand();

    myFile<<currentPlayer.getName()<<"'s book is now ";
    myFile<<currentPlayer.showBooks();
    currentPlayer.showBooks();


    myFile<<otherPlayer.getName()<<"'s hand is now ";

    myFile<<otherPlayer.showHand();


}
else {

    myFile<<otherPlayer.getName()<< " says to go fish"<<endl;

    dealOneCard(d,currentPlayer);

    myFile<<currentPlayer.getName()<< " draws a card "<<endl;
    myFile<<currentPlayer.getName()<< "'s hand is now ";

    myFile<<currentPlayer.showHand();

    Card pairHolder1; Card pairHolder2;

    while(currentPlayer.checkHandForBook(pairHolder1,pairHolder2) ==true){
        currentPlayer.removeCardFromHand(pairHolder1);
        currentPlayer.removeCardFromHand(pairHolder2);
        currentPlayer.bookCards(pairHolder1,pairHolder2);    //add cards to book

        myFile<<currentPlayer.getName()<< " puts " <<pairHolder1<< " and "<<pairHolder2<< " into their book"<<endl;
    }


    return true;
}

return true;
}

void playGame(Deck &d, Player &playerOne, Player &playerTwo){

    while(true){
        if(takeTurn(d,playerOne,playerTwo) == false ){//takes playerOnes turn and checks if the game has ended
            return;
        }


        myFile<<endl;

        if(takeTurn(d,playerTwo,playerOne) == false ){//takes playerTwos turn and checks if the game has ended
            return;
        }

        myFile<<endl;
    }

}


int main(int argc, char *argv[]) {
    char fName[MAX_NAME];
    strcpy(fName,argv[1]);//get the name of the file

    myFile<<fName<<endl;



    myFile.open(fName, ios::out | ios::trunc);



//create the players and the deck objects
Deck d1;
Player Ottavio("Ottavio");
Player Eric("Eric");

//shuffle the deck
d1.shuffle();

//check player functions
dealHand(d1,Ottavio,HAND_SIZE);
    dealHand(d1,Eric,HAND_SIZE);
    myFile<<"Ottavio's starting hand is ";
    Ottavio.showHand();
    myFile<<Ottavio.showHand();
    myFile<<endl;


    Card pairHolder1; Card pairHolder2;
    while(Ottavio.checkHandForBook(pairHolder1,pairHolder2) ==true){
        myFile<<Ottavio.getName()<< " puts " <<pairHolder1<< " and "<<pairHolder2<< " into their book"<<endl;
        Ottavio.removeCardFromHand(pairHolder1);
        Ottavio.removeCardFromHand(pairHolder2);
        Ottavio.bookCards(pairHolder1,pairHolder2);    //add cards to book
    }

    myFile<<endl;
    myFile<<"Eric's starting hand is ";
    Eric.showHand();
    myFile<<Eric.showHand();
    myFile<<endl;

    Card pairHolder3; Card pairHolder4;
    while(Eric.checkHandForBook(pairHolder1,pairHolder2) ==true){
        myFile<<Eric.getName()<< " puts " <<pairHolder1<< " and "<<pairHolder2<< " into their book"<<endl;
        Eric.removeCardFromHand(pairHolder1);
        Eric.removeCardFromHand(pairHolder2);
        Eric.bookCards(pairHolder1,pairHolder2);    //add cards to book
    }


    srand (time(nullptr));
    int random = rand() % 100  ;


    myFile<<endl;
    if(random < 50){

        myFile<<"Ottavio wins the coin toss and goes first"<<endl;
        myFile<<endl;
        playGame(d1,Ottavio,Eric);
    }
    else {

        myFile<<"Eric wins the coin toss and goes first"<<endl;
        myFile<<endl;
        playGame(d1,Eric,Ottavio);
    }


    myFile <<"The game is over and it's time to determine who won"<<endl;
    int OttavioScore = Ottavio.getBookSize()/2;
    int EricScore = Eric.getBookSize()/2;


    myFile <<Ottavio.getName()<<" assembled " << OttavioScore<<" books"<<endl;
    myFile <<Eric.getName()<<" assembled " << EricScore<<" books"<<endl;

    if(OttavioScore > EricScore){

        myFile<<Ottavio.getName()<<" won"<<endl;
    }

    if(EricScore > OttavioScore){

        myFile<<Eric.getName()<<" won the game!"<<endl;
    }

    if(EricScore == OttavioScore){

        myFile<<"The game was a tie"<<endl;
    }




    myFile.close();

}

