//
// Created by ottav on 9/29/2020.
//

#ifndef PROG03LINKED_STACK312_LL_H
#define PROG03LINKED_STACK312_LL_H
#define MAXCHAR 1000
#endif //PROG03LINKED_STACK312_LL_H


//
// Created by ottav on 9/29/2020.
//


#include <stdio.h>
#include <stdbool.h>

typedef struct Pixel {
    int row;
    int col;
    char color;
} Pixel;

typedef Pixel StackEntry;

typedef struct StackNode {
    StackEntry pixel;
    struct StackNode *next;
} StackNode;

typedef struct Stack312 {
    struct StackNode *top;
} Stack312;

void makeStack(Stack312 *sp);

bool isFull(Stack312 s);

bool isEmpty(Stack312 s);

void push(StackEntry e,Stack312 *sp);

StackEntry pop(Stack312 *sp);

void detSize(char fName[],int *numRows, int *numCols);

void alloMatrix(char *matrix[],int* numCols, int* numRows);

void copyWorld(char fName[], char *grid[], int *numRows, int *numCols );

void showPicture(char *grid[], int numRows, int numCols);

void processInput(int rowInput, int colInput, char colorInput, Stack312 stack, char* matrix[]);

void checkThatStackWorks(struct Stack312 stack);

void freeMatrix(char *matrix[],int* numCols, int* numRows);