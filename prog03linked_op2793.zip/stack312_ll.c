//
// Created by ottav on 9/29/2020.
//


#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#define MAXCHAR 1000
typedef struct Pixel {
    int row;
    int col;
    char color;
} Pixel;

typedef Pixel StackEntry;

typedef struct StackNode {//structure of stackNode
    StackEntry pixel;
    struct StackNode *next;
} StackNode;

typedef struct Stack312 {//structure of Stack312
    struct StackNode *top;
} Stack312;

void makeStack(Stack312 *sp){//sets the top of the stack
    sp->top =NULL; //

}

bool isFull(Stack312 s){//checks if the stack is full, returns 1 if full
    StackEntry *check = (StackEntry*)malloc(sizeof(StackEntry));
    if(check == NULL){
        free(check);
        return 1;
    }
    free(check);
    return 0;
}

bool isEmpty(Stack312 s){//checks if the stack is empty
    if(s.top == NULL){
        return 1;
    }
    return 0;
}

void push(StackEntry e,Stack312 *sp){//pushes given element to the stack
    struct StackNode *oldtop = sp->top;//stores what top pointed to
    struct StackNode *newtop = (struct StackNode*)malloc(sizeof(StackNode));//allocate space for the new node
    sp->top = newtop;
    newtop->next = oldtop;//sets
    newtop-> pixel =e;




}

void detSize(char fName[],int *numRows, int *numCols){//determines the number of rows and columns of the picture
    FILE *fp;
    char str[MAXCHAR];
    int cols = 0;
    int rows = 0;//declare the variables to be used in this function

    //opens and checks the file
    fp = fopen(fName, "r");//open the file

    while (fgets(str, MAXCHAR, fp) != NULL){
        cols = strlen(str);//the # of cols=# of elements in row
        rows ++;}
    fclose(fp);

    *numRows = rows;//store sizevalue
    *numCols = cols;//store sizevalue
}


StackEntry pop(Stack312 *sp){//pops top element of the stack
    struct StackNode *newtop = sp->top->next;//save the next node, which will be the new node
    StackEntry output = sp->top->pixel;
    free(sp->top);
    sp->top = newtop;
    return output;
}

void alloMatrix(char *matrix[],int* numCols, int* numRows){//allocates the 2d array entered
    for(int i = 0; i<*numRows; i ++){
        matrix[i] = (char *)malloc(*numCols * sizeof(char));

    }
}

void freeMatrix(char *matrix[],int* numCols, int* numRows){//allocates the 2d array entered
    for(int i = 0; i<*numRows; i ++){
        free(matrix[i]);

    }
}




void copyWorld(char fName[], char *grid[], int *numRows, int *numCols ){//copies the picture to the 2d array
    FILE *fp;
    char str[MAXCHAR];
    int idx = 0;

    fp = fopen(fName, "r");
    if (fp == NULL){
        printf("Can't open file %s",fName);
    }
//this performs the actual copying
    while(fgets(str, MAXCHAR, fp)!=NULL){
        str[*numCols] = '\0';//replaces last char (newline) with a null
        strcpy(grid[idx],str);//copies from str into grid[idx]
        idx++;
    }
    fclose(fp);
}


void showPicture(char *grid[], int numRows, int numCols){//print out the picture to the console
    for(int i = 0;i < numRows; i++){
                printf("%s\n",grid[i]);
        }


}


void checkThatStackWorks(struct Stack312 stack){
    StackEntry pixel1;
    pixel1.row =1;
    pixel1.col = 2;
    pixel1.color ='c';
    printf("%d\n",isEmpty(stack));
    push(pixel1,&stack);
    printf("%d\n",isEmpty(stack));
    printf("%c\n",pop(&stack).color);
    printf("%d\n",isEmpty(stack));
}