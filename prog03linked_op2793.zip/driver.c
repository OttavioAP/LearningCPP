#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include "stack312_ll.h"

#define MAX_NAME_LENGTH 200

//start variable dec
int numRows;
int numCols;
char oldColor;
char colorInput = 0;
int colInput =0;
int rowInput =0;
int rowCheck = 0;
int colCheck = 0;
//end variable dec

int main(int argc, char *argv[]) {

   //declare stack
    Stack312 stack;
    makeStack(&stack);
    //end stack declaration

    //get name of picture file
    char fileName[MAX_NAME_LENGTH];
    strcpy(fileName, argv[1]);

    //get size of picture
    detSize(fileName,&numRows,&numCols);

    //checks for too large of a file
    if(numRows > 255 ||numCols > 25){
        printf("input file is too large\n");
        return 0;
    }

    //init 2d array to hold picture
    char* matrix[numRows];
    alloMatrix(matrix,&numCols,&numRows);

    //copy to 2d array
    copyWorld( fileName,matrix,  &numRows, &numCols );

    //get row input/


while(1) {//this loop continues until -1 is inputted

    //print out the picture
    showPicture(matrix,numRows,numCols);

    //get color input
    printf("input a color\n");
    scanf(" %c", &colorInput);

    //get row input, check for -1
    rowCheck = 0;

    while(rowCheck == 0){
        printf("input a row between 0 and %d\n",(numRows-1));
        scanf(" %d", &rowInput);
        if(rowInput == -1){
            freeMatrix(matrix,&numCols,&numRows);
            return 0;
        }
        if(rowInput < numRows && rowInput > -1){
            rowCheck = 1;
        }
        else {
            printf("invalid row input, try again\n");
        }
    }

    colCheck = 0;

    while(colCheck == 0){
        printf("input a column between 0 and %d\n",(numCols-1));
        scanf(" %d", &colInput);
        if(colInput == -1){
            freeMatrix(matrix,&numCols,&numRows);
            return 0;
        }
        if(colInput < numCols && colInput > -1){
            colCheck = 1;
        }
        else {
            printf("invalid column input, try again\n");
        }
    }

    //makes oldColor the previous color of the inputted element
    oldColor = matrix[rowInput][colInput];

    //declare input pixel
    StackEntry input;// = (StackEntry*)malloc(sizeof(StackEntry));
    input.col = colInput;
    input.row = rowInput;
    input.color = colorInput;
    matrix[input.row][input.col] = input.color;

    //push input pixel to the stack
    push(input,&stack);

    //loop until stack empties aka when all neighbors are colored, if neighbors have the same corresponding oldColor, they get changed and pushed
    while(isEmpty(stack) == 0){

        //pop the top of the stack
        Pixel topPixel = pop(&stack);

        //check for upper neighbor, colors and pushes if it matches oldColor
        if(topPixel.row > 0){//there's only an upper neighbor if this char isn't from the 0th row
            if(matrix[topPixel.row-1][topPixel.col] == oldColor){
                matrix[topPixel.row-1][topPixel.col] = colorInput;
                StackEntry *neighbor = (StackEntry*)malloc(sizeof(StackEntry));
                neighbor->row = topPixel.row-1;
                neighbor->col = topPixel.col;
                neighbor->color = matrix[topPixel.row-1][topPixel.col];
                push(*neighbor,&stack);
                free(neighbor);
            }
        }

        //check for lower neighbor, colors and pushes if it matches oldColor
        if(topPixel.row < numRows-1){//there's only a lower neighbor if the char isn't in the last row
            if(matrix[topPixel.row+1][topPixel.col] == oldColor){//checks if the lower neighbor is the oldcolor
                matrix[topPixel.row+1][topPixel.col] = colorInput;//assigns the newColor to the neighbor
                StackEntry *neighbor2 = (StackEntry*)malloc(sizeof(StackEntry));
                neighbor2->row = topPixel.row+1;
                neighbor2->col = topPixel.col;
                neighbor2->color = matrix[topPixel.row+1][topPixel.col];
                push(*neighbor2,&stack);
                free(neighbor2);
            }
        }

        //check for left neighbor, colors and pushes if it matches oldColor
        if(topPixel.col > 0){//there's only a left neighbor if the char isn't in the last row
            if(matrix[topPixel.row][topPixel.col-1] == oldColor){//checks if the left neighbor is the oldcolor
                matrix[topPixel.row][topPixel.col-1] = colorInput;//assigns the newColor to the neighbor
                StackEntry *neighbor3 = (StackEntry*)malloc(sizeof(StackEntry));
                neighbor3->row = topPixel.row;
                neighbor3->col = topPixel.col-1;
                neighbor3->color = matrix[topPixel.row][topPixel.col-1];
                push(*neighbor3,&stack);
                free(neighbor3);
            }
        }

        //check for right neighbor, colors and pushes if it matches oldColor
        if(topPixel.col < numCols-1){//there's only a right neighbor if the char isn't in the last col
            if(matrix[topPixel.row][topPixel.col+1] == oldColor){//checks if the left neighbor is the oldcolor
                matrix[topPixel.row][topPixel.col+1] = colorInput;//assigns the newColor to the neighbor
                StackEntry *neighbor4 = (StackEntry*)malloc(sizeof(StackEntry));
                neighbor4->row = topPixel.row;
                neighbor4->col = topPixel.col+1;
                neighbor4->color = matrix[topPixel.row][topPixel.col+1];
                push(*neighbor4,&stack);
                free(neighbor4);
            }
        }

        //check for top left neighbor, colors and pushes if it matches oldColor
        if(topPixel.col > 0 && topPixel.row >0){//there's only a top left neighbor if the char isn't in the last col
            if(matrix[topPixel.row-1][topPixel.col-1] == oldColor){
                matrix[topPixel.row-1][topPixel.col-1] = colorInput;//assigns the newColor to the neighbor
                StackEntry *neighbor5 = (StackEntry*)malloc(sizeof(StackEntry));
                neighbor5->row = topPixel.row-1;
                neighbor5->col = topPixel.col-1;
                neighbor5->color = matrix[topPixel.row-1][topPixel.col-1];
                push(*neighbor5,&stack);
                free(neighbor5);
            }
        }

        //check for top right neighbor, colors and pushes if it matches oldColor
        if(topPixel.col < (numCols-1) && topPixel.row > 0){//there's only a top right neighbor if the char isn't in the last col
            if(matrix[topPixel.row-1][topPixel.col+1] == oldColor){
                matrix[topPixel.row-1][topPixel.col+1] = colorInput;//assigns the newColor to the neighbor
                StackEntry *neighbor6 = (StackEntry*)malloc(sizeof(StackEntry));
                neighbor6->row = topPixel.row-1;
                neighbor6->col = topPixel.col+1;
                neighbor6->color = matrix[topPixel.row-1][topPixel.col+1];
                push(*neighbor6,&stack);
                free(neighbor6);
            }
        }
        //check for lower left neighbor, colors and pushes if it matches oldColor
        if(topPixel.col >0 && topPixel.row < (numRows-1)){//there's only a bottom left neighbor if the char isn't in the last col
            if(matrix[topPixel.row+1][topPixel.col-1] == oldColor){
                matrix[topPixel.row+1][topPixel.col-1] = colorInput;//assigns the newColor to the neighbor
                StackEntry *neighbor7 = (StackEntry*)malloc(sizeof(StackEntry));
                neighbor7->row = topPixel.row+1;
                neighbor7->col = topPixel.col-1;
                neighbor7->color = matrix[topPixel.row+1][topPixel.col-1];
                push(*neighbor7,&stack);
                free(neighbor7);
            }
        }

        //checks for bottom right diagonal, colors and pushes if it matches oldColor
        if(topPixel.col <(numCols -1) && topPixel.row < (numRows-1)){//there's only a bottom right neighbor if the char isn't in the last col
            if(matrix[topPixel.row+1][topPixel.col+1] == oldColor){
                matrix[topPixel.row+1][topPixel.col+1] = colorInput;//assigns the newColor to the neighbor
                StackEntry *neighbor8 = (StackEntry*)malloc(sizeof(StackEntry));
                neighbor8->row = topPixel.row+1;
                neighbor8->col = topPixel.col+1;
                neighbor8->color = matrix[topPixel.row+1][topPixel.col+1];
                push(*neighbor8,&stack);
                free(neighbor8);
            }

        }




    }//loop until stack empties, out of neighbors


}//loop until input is -1


}
