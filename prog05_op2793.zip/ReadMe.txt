Written by Immaculate Fombo and Ottavio Peruzzi (OP2793)

instructions to run

unzip prog05.zip
compile program with command make
run program with command ./utpod
to check for memory leaks use valgrind ./utpod

The output of this function will demonstrate the functionality of the UTPod class

There are no known bugs in this program