/*
 * Song class declarations
 * Ottavio Peruzzi
 * Op2793
 */

#ifndef UTPOD2_SONG_H
#define UTPOD2_SONG_H
#include <string>
#include <iostream>

using namespace std;
class Song {
private:


    int size;
    string artist;
    string title;
    static const int default_size =1;
public:
    //constructors
    Song(string SongTitle, string SongArtist, int SongSize);//constructs Song object
    Song();
    //getters and setters
    void setTitle(string title);//sets private variables
    void setSize(int size);
    void setArtist(string artist);
    string getTitle() const;//gets private variables
    string getArtist() const;
    int getSize() const;
    //swaps two songs
    void swap(Song &p);//swaps variables of song objects
    //operator definition
    bool operator >(Song const &rhs);//compares song object
    bool operator <(Song const &rhs);
    bool operator ==(Song const &rhs);
    void operator =(Song const &rhs);//copy constructor
};
ostream& operator << (ostream& out, const Song &g);




#endif //UTPOD2_SONG_H
