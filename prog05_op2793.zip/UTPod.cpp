//
// Ottavio Peruzzi
// * Op2793
//UTPod class function definitions
//

#include "UTPod.h"
#include <iostream>
#include <string>
#include <cstdlib>
#include <ctime>

using namespace  std;
//constructors
UTPod::UTPod() {
    memSize = MAX_MEMORY;
    songs =nullptr;
}
UTPod::UTPod(int podSize) {
    if(podSize <= 0){
        memSize = MAX_MEMORY;
    }
    else if(podSize > MAX_MEMORY){
        memSize = MAX_MEMORY;
    }
    else {
        memSize =podSize;
    }
    songs = nullptr;
}

int UTPod::addSong(const Song &s) {
    if(s.getSize()>getRemainingMemory()){
        cout<<"disk full"<<endl;
        return NO_MEMORY;
    }


    SongNode *newHolder = new SongNode;//makes a new node to add to the playlist
    newHolder->s = s;//sets that nodes song = to s
    newHolder->next = songs;
    songs = newHolder;
    return SUCCESS;
}

int UTPod::getNumberOfSongs(){
    int count =0;
    SongNode *traverse = songs;

    while(traverse != nullptr) {
        count++;
        traverse = traverse->next;
    }
    delete(traverse);
    return count;
}

void UTPod::setSize(int size) {
    memSize = size;
}

int UTPod::shuffle(){
    if(songs == nullptr ||songs->next == nullptr){
        cout<<"Not enough songs to shuffle"<<endl;
        return NO_MEMORY;
    }
    srand (time(nullptr));
    SongNode* traverse;
    int songNum = this->getNumberOfSongs();//gets length of linked list

    for(int i =0;i<(1000);i++) {
        traverse = songs;
        int random = rand() % (songNum-1) + 1;
        for (int i = 0; i < random; i++) {//gets a random link in the linked list
            traverse = traverse->next;
        }
        songs->s.swap(traverse->s);
    }
    return SUCCESS;
}

UTPod::UTPod(const UTPod& origClass){//copy constructor
    cout<<"copyConstructor Called"<<endl;
    if((origClass.memSize <=0) || (origClass.memSize>MAX_MEMORY)){
        memSize = MAX_MEMORY;
    }
    else{
        memSize = origClass.memSize;
    }
    songs = nullptr;

}

void UTPod::sortSongList() {//selectionsort

    SongNode* currValue = songs;
    SongNode* traversal;

    while(currValue->next !=nullptr){
        for(traversal = currValue; traversal != nullptr;traversal =traversal->next){
            if(traversal->s < currValue->s){
                traversal->s.swap(currValue->s);//swaps if it finds a lower value
            }
        }
        currValue = currValue->next;//increments currValue


    }
}

void UTPod::clearMemory() {
    SongNode* traverse = songs;
    SongNode* temp;

    while(traverse !=nullptr){
        temp =traverse->next;
        delete(traverse);
        traverse =temp;
    }
    songs =nullptr;
    delete(traverse);
    delete(temp);


}

int UTPod::getTotalMemory() {
    return memSize;
}

int UTPod::getRemainingMemory() {
    int usedMemory = 0;
    SongNode* traversal;

    for(traversal =songs;traversal !=nullptr;traversal=traversal->next ){
        usedMemory += traversal->s.getSize();
    }
    delete(traversal);
    return memSize - usedMemory;//returns remaining memnory
}

UTPod::~UTPod(){
    this->clearMemory();
    delete(songs);
}

void UTPod::showSongList() {
    if(songs == nullptr){
        cout<<"no songs found"<<endl;
        return;
    }

    SongNode* traversal;
    for(traversal =songs; traversal != nullptr;traversal = traversal->next){
        cout<<traversal->s;
    }
}

int UTPod::removeSong(const Song &s) {
    if(songs == nullptr){
        cout<<"no songs found"<<endl;
        return NOT_FOUND;
    }
    SongNode* traversal;
    SongNode* temp;
for(traversal =songs; traversal->next != nullptr; traversal =traversal->next){
    if(traversal == songs && traversal->s == s && traversal->next == nullptr){//if there is only one item and it's s
        songs = nullptr;
        delete(traversal);
        return SUCCESS;
    }
    if(traversal == songs && traversal->s == s){//if its the first but its not the only
        songs = traversal->next;
        delete(traversal);
        return SUCCESS;
    }
    if(traversal->next->s == s){//regular case
        temp = traversal->next;
        traversal->next = traversal->next->next;
        delete(temp);
        return SUCCESS;
    }
}
cout<<"song not found"<<endl;
return NOT_FOUND;
}
