/*
 * Ottavio Peruzzi
 * OP2793
 * Song class definitions
 */

#include "Song.h"
using namespace std;

Song::Song() {
    artist ="artist not found";
    title ="title not found";
    size =1;
}
Song::Song(string SongTitle, string SongArtist, int SongSize){
    title = SongTitle;
    artist = SongArtist;
    size = SongSize;
}
string Song::getArtist() const {

    return artist;
}
string Song::getTitle() const {
    return title;
}
int Song::getSize() const {
    return size;
}
void Song::setSize(int SongSize) {
    this->size = SongSize;
}
void Song::setArtist(string SongArtist) {
    this->artist =SongArtist;
}
void Song::setTitle(string SongTitle) {
    this->title =SongTitle;
}
//swap
void Song::swap(Song &s)
{
    Song RightSong = s;
    s = *this;
    *this = RightSong;
}
//operators
bool Song::operator >(Song const &rhs) {
    if (this->artist > rhs.artist) {
        return 1;
    }
    if (this->artist < rhs.artist) {
        return 0;
    }

    if (this->title > rhs.title) {
        return 1;
    }
    if (this->title < rhs.title) {
        return 0;
    }

    if (this->size > rhs.size) {
        return 1;
    }
    if (this->size < rhs.size) {
        return 0;
    }
    return 0;
}
bool Song::operator <(Song const &rhs)
{
    if(this->artist < rhs.artist){
        return 1;
    }
    if(this->artist > rhs.artist){
        return 0;
    }

    if(this->title < rhs.title){
        return 1;
    }
    if(this->title > rhs.title){
        return 0;
    }

    if(this->size < rhs.size){
        return 1;
    }
    if(this->size > rhs.size){
        return 0;
    }
    return 0;

}
bool Song::operator ==(Song const &rhs)
{
    if(this->title==rhs.title){
        if(this->artist == rhs.artist){
            if(this->size == rhs.size){
                return true;
            }
        }
    }
    return false;
}
void Song::operator =(Song const &rhs){
    this->title = rhs.title;
    this->artist = rhs.artist;
    this->size = rhs.size;
}
ostream& operator << (ostream& out, const Song &g)
{
    out << g.getTitle()<<", " << g.getArtist() << ", " << g.getSize()<<" Megabytes"<<endl;
    return out;
}