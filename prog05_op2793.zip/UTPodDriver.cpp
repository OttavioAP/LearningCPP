/*Ottavio Peruzzi
 * Op2793
 * Driver for UTPod
 */

#include <cstdlib>
#include <iostream>
#include "Song.h"
#include "UTPod.h"

using namespace std;

int main() {

    cout<<endl<<endl;
    cout<< "Hello to the T.A reading this. I hope you're having a nice day "<< endl;

    cout<< "First we will test the ability to create a UTPod of a certain size"<<endl;
    cout<<endl;

    cout<<"We will declare a UTPod Named t"<<endl;
    cout<<endl;
    UTPod t;

    cout<<"Since UTPod was declared without a size parameter it has defaulted to the maximum size of a UTPod, which is 512 "<<endl;
    cout<<endl;

    cout<<"t size is "<<t.getRemainingMemory()<<" MB"<<endl;
    cout<<endl;



    cout<<"we set the size of t to 400 "<<endl;
    cout<<endl;
    t.setSize(400);
    cout<<"t size is "<<t.getRemainingMemory()<<" MB"<<endl;
    cout<<endl;
    cout<<"If you call showSongList with an empty UTPod it has a special case output"<<endl;
    t.showSongList();
    cout<<"If you create an Song object with no parameters it is defaulted to title not found, artist not found, 1 Megabytes"<<endl;

    Song s101;
    t.addSong(s101);
    t.showSongList();
    t.clearMemory();
    cout<<"now I will add 10 songs to the UTPod and then display them"<<endl;
    Song s1("Jump", "Van Halen", 35);
    t.addSong(s1);
    Song s2("I want to ride my bicycle", "queen", 17);
    t.addSong(s2);
    Song s3("Saturn Missiles", "Aesop Rock", 39);
    t.addSong(s3);
    Song s4("Skelethon", "Aesop Rock", 12);
    t.addSong(s4);
    Song s5("Skelethon", "Aesop Rock", 12);
    t.addSong(s5);
    Song s6("Blinded by the Light", "Eagles of Death Metal", 64);
    t.addSong(s6);
    Song s7("Blinded by the Light", "Manfredd Mans Earth Band", 63);
    t.addSong(s7);
    Song s8("The Wall", "Pink Floyd", 27);
    t.addSong(s8);
    Song s9("Everybody Wants to be A Cat", "Various Artists", 34);
    t.addSong(s9);
    Song s10("Song For Elias", "The Cat Empire", 49);
    t.addSong(s10);
    cout<<endl;
    t.showSongList();
    cout<<endl<<endl;

    cout<<"I get an error message if I attempt to add a song that there is not room for, and I am prevented from adding it "<<endl<<endl;
    Song s30("Song For Elias", "The Cat Empire", 349);
    t.addSong(s10);




    cout<<"we can see that the disk space left on the UTPod has decreased"<<endl;
    cout<<endl;
    cout<<"size left on t is "<<t.getRemainingMemory()<<" MB"<<endl;
    cout<<endl;
    cout<<"now that we have a playlist we can perform various operations on it"<<endl;
    cout<<endl;
    cout<<"we can randomize the playlist by shuffling it"<<endl;
    cout<<endl;
    t.shuffle();
    t.showSongList();
    cout<<endl<<endl;
    cout<<"we can shuffle it as many times as we want and get a different result"<<endl;
    cout<<endl;
    t.shuffle();
    t.showSongList();
    cout<<endl<<endl;

    t.shuffle();
    t.showSongList();
    cout<<endl<<endl;

    cout<<"We can sort the UTPod in ascending order by Artist"<<endl<<endl;
    t.sortSongList();
    t.showSongList();
    cout<<endl<<endl;
    cout<<"This process can be repeated as many times as we want, to demonstrate I'll shuffle and then sort again"<<endl<<endl;

    cout<<endl<<endl;
    t.shuffle();
    t.showSongList();
    cout<<endl<<endl;

    t.sortSongList();
    t.showSongList();
    cout<<endl<<endl;

    cout<<"In addition to adding songs we can also remove songs"<<endl<<endl;
    cout<<"We will remove Saturn Missiles from the playlist "<<endl<<endl;
    t.removeSong(s3);
    cout<<endl<<endl;
    t.showSongList();
    cout<<endl<<endl;
    cout<<"We will also remove one of the Skelethon instances "<<endl<<endl;
    t.removeSong(s4);
    cout<<endl<<endl;
    t.showSongList();
    cout<<"It only gets rid of one of the instances, not every version "<<endl<<endl;
    cout<<"Now that some songs have been removed the UTPod has more space on the disk "<<endl<<endl;
    cout<<"The remaining memory is "<<t.getRemainingMemory()<<" MB"<<endl<<endl;

    cout<<"If I attempt to get rid of a song that is not on the UTPod I get a special output case"<<endl;
    Song s100("song bing bang badoo", "horace slughorn", 23);
    t.removeSong(s100);
    cout<<"I can perform functions directly on songs. For example I can set and get the artist, title and size of song8"<<endl<<endl;
    cout<<s8<<endl;
    cout<<"I will alter the artist of song8"<<endl<<endl;
    s8.setArtist("Queens of the Stone Age");
    cout<<s8<<endl;
    cout<<"I will alter the title of song8"<<endl<<endl;
    s8.setTitle("Big Dans Plastic Knee");
    cout<<s8<<endl;
    cout<<"I will alter the size of song8"<<endl<<endl;
    s8.setSize(43);
    cout<<s8<<endl;


    cout<<"If I want to clear all of the memory of the UTPod I can do so by calling the clearMemory function"<<endl<<endl;
    t.clearMemory();
    cout<<"after clearing UTPod the remaining memory is equal to the full memory the UTPod was initialized with"<<endl<<endl;
    cout<<"The remaining memory is "<<t.getRemainingMemory()<<" MB"<<endl<<endl<<endl;
    cout<<"The functions showSongList and shuffle now have special output cases"<<endl<<endl;
    cout<<"here is the output of showSongList"<<endl<<endl;
    t.showSongList();
    cout<<"here is the output of shuffle"<<endl<<endl;
    t.shuffle();
    cout<<"the UTPod isn't destroyed by clearMemory, you can still add songs to it and perform functions on it"<<endl<<endl;
    cout<<"now I will add 6 songs to UTPod and then display them"<<endl<<endl;
    Song s11("Jump", "Van Halen", 35);
    t.addSong(s1);
    Song s12("I want to ride my bicycle", "queen", 17);
    t.addSong(s2);
    Song s13("Saturn Missiles", "Aesop Rock", 39);
    t.addSong(s3);
    Song s14("Skelethon", "Aesop Rock", 12);
    t.addSong(s4);
    Song s15("Skelethon", "Aesop Rock", 12);
    t.addSong(s5);
    Song s16("Blinded by the Light", "Eagles of Death Metal", 64);
    cout<<"here is the output of showSongList"<<endl;
    t.showSongList();

    cout<<"I have written a destructor for the function which prevents memory leaks."<<endl;
}
